
//  code js de la premiere page 

document.addEventListener("DOMContentLoaded", function () {
    const contactButton = document.getElementById("contactButton");
    const contactPage = document.getElementById("contactPage");
    const closeContactPage = document.getElementById("closeContactPage");
  
    contactButton.addEventListener("click", function () {
      contactPage.style.display = "block";
    });
  
    closeContactPage.addEventListener("click", function () {
      contactPage.style.display = "none";
    });
  });



  
  